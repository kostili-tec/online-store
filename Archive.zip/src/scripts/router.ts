import { Page404 } from './pages/Page404';
import { Home } from './pages/Home';
import { ProductDetails } from './pages/ProductDetails';

export const root = document.createElement('main');
root.className = 'container';

export interface IQueryParameters {
  [key: string]: string;
}
interface IRoutes {
  [key: string]: {
    name: string;
    page: (container: HTMLElement, params: IQueryParameters) => void;
  };
}

export const routes: IRoutes = {
  page404: {
    name: 'Error 404',
    page: Page404,
  },
  '/': {
    name: 'Home',
    page: Home,
  },
  '/product': {
    name: 'Product details',
    page: ProductDetails,
  },
};

export const navigate = (href: string, e?: Event) => {
  if (e instanceof Event) e.preventDefault();
  window.history.pushState({}, '', href);
  handleLocation();
};

const handleLocation = () => {
  const path = window.location.pathname;
  const query = new URLSearchParams(window.location.search);
  const route = routes[path] || routes['page404'];
  route.page(root, Object.fromEntries(query));
  document.title = `Online Store - ${route.name}`;
};

window.onpopstate = handleLocation;

handleLocation();
