import { IQueryParameters } from '../router';
import { getProducts, IProducts, IProduct } from '../testApi';

export async function Home(container: HTMLElement, query: IQueryParameters) {
  const data: IProducts = await getProducts();
  if (!data.products) {
    console.log('shit no products');
    return;
  }

  const div = document.createElement('div');
  div.textContent = 'This is homepage!';

  const pickedCategories = query.category?.split(',') ?? [];

  const categories = document.createElement('div');
  getCategories(data).forEach((cat) => {
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.value = cat;
    if (pickedCategories.includes(cat)) input.checked = true;
    categories.append(input, cat);
  });

  const productsContainer = document.createElement('div');
  filterProducts(productsContainer, data.products, pickedCategories);

  categories.oninput = (e: Event) => {
    const input = e.target as HTMLInputElement;
    let pickedCategories = query.category?.split(',') ?? [];
    if (input.checked) {
      pickedCategories.push(input.value);
    } else {
      pickedCategories = pickedCategories.filter((cat) => cat !== input.value);
    }
    query.category = pickedCategories.join(',');
    const q = new URLSearchParams(query).toString();
    window.history.replaceState({}, '', '?' + q);
    filterProducts(productsContainer, data?.products ?? [], pickedCategories);
  };

  container.replaceChildren(div, categories, productsContainer);
}

function getCategories(data: IProducts): string[] {
  const categories = data.products?.map((product) => product.category) ?? [];
  return categories.filter((value, index, self) => self.indexOf(value) === index);
}

function filterProducts(container: HTMLElement, products: IProduct[], categories: string[]) {
  const filteredProducts = products
    .filter((product) => categories.length === 0 || categories.includes(product.category))
    .map((product) => {
      const productCard = document.createElement('div');
      productCard.textContent = product.title;
      return productCard;
    });
  container.replaceChildren(...filteredProducts);
}
