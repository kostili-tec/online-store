import { root } from './router';

document.body.replaceChildren(root);
